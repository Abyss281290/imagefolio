<table id="table86595"> 
<tbody> 
	<tr> 
		<td><h3>On this page...</h3> 
<p>it would be appropriate to introduce your agency, who your client base are or mention<br>some of the more well-known talent, of course, delete the content that is here.</p></td> 
		<td>Here would be a nice spot to place a picture of your agency or of the staff.<img class="img_right" alt="" src="/images/editor/3819936c90ab5d4d7fb3d979798679be.jpg"> 
<br></td> 
	</tr> 
	<tr> 
		<td> 
<p>here would be a nice place to upload a few covers you are responsible for producing. 
<br><img alt="" src="/images/editor/25c4fdf43f43ab0b50364b199aac86ed.jpg" class="=&quot;img_left&quot;"> 
<br></p> </td> 
		<td> 
<p>We have a number of layouts that we can suggest for these pages, or you could<br>send us the content you would like placed on them, and we will do it for you.</p></td> 
	</tr> 
</tbody> 
</table>