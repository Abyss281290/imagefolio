<table id="table86595"> 
<tbody> 
	<tr> 
		<td><h3>On this page...</h3> 
<p>it would be appropriate to list your address, contact and details times your office is open for walk-ins.
<br>
<br>Of course, delete the content that is here.</p></td> 
		<td> 
<p>Here would be a nice spot to place a google map to your office</p><iframe marginheight="0" marginwidth="0" src="https://maps.google.com/?ie=UTF8&amp;ll=40.74809,-73.984798&amp;spn=0.001674,0.003484&amp;t=m&amp;z=19&amp;output=embed" frameborder="0" height="350" scrolling="no" width="425"></iframe> 
<br><small><a href="https://maps.google.com/?ie=UTF8&amp;ll=40.74809,-73.984798&amp;spn=0.001674,0.003484&amp;t=m&amp;z=19&amp;source=embed">View Larger Map</a></small></td> 
	</tr> 
	<tr> 
		<td> 
<p>here would be a nice place to upload a few covers you are responsible for.</p> </td> 
		<td> 
<p>We have a number of layouts that we can suggest for these pages, or you could send us the content<br>you would like placed on them, and we will do it for you.</p></td> 
	</tr> 
</tbody> 
</table>