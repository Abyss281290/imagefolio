<p>Here it would be nice to upload a Jpeg image or Flash Intro with a width of 940px, but any HTML code will work. <img alt="Front Page Splash" src="/images/editor/791b91d2c2d0a8638676b06f642e80e3.jpg" class="=&quot;img_left&quot;"> 
<br> 
<br></p>